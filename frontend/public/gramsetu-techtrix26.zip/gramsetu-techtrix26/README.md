# GramSetu (ग्रामसेतु) — TechTrix'26 (Problem Statement 1)

> **Digital Rural Development Scheme Monitoring & Beneficiary Verification Platform**  
> Built for TechTrix'26 Hackathon | Problem Statement 1 (PS-1)

---

## 🌾 Project Overview

**GramSetu** is a digital public-infrastructure web application connecting State Administrators, District Officers (DM/CDO), Block Development Officers (BDO), Frontline Field Technical Inspectors, and Rural Citizens into one transparent, accountable platform.

### Key Objectives:
- **Comprehensive Scheme Directory**: Real-time progress and budget monitoring for PMAY-G, Jal Jeevan Mission, Swachh Bharat Mission (Gr.), PMGSY, Amrit Sarovar, and Rural Solar Urja.
- **9-Step Statutory Beneficiary Verification**: Multi-factor eligibility checklist, duplicate identity detection, and mandatory justification logging.
- **Offline Field Inspections**: Tablet-optimized inspection workspace with hardware GPS lock and client-side **SHA-256 cryptographic byte hashing** for site evidence photos.
- **Stage Installment Approvals**: Direct Benefit Transfer (DBT) approval workflow with prerequisite milestone verification and PFMS simulated transaction records.
- **Explainable Fraud & Risk Intelligence**: 0–100 deterministic risk scoring detecting SHA-256 photo hash reuse across different beneficiaries, geo-fence deviations (>28 km discrepancy), and asset roster mismatches.
- **Geographic Intelligence**: Interactive spatial mapping using Leaflet and OpenStreetMap.
- **Bilingual GramSetu Sahayak AI**: Natural language assistant in Hindi (हिन्दी) and English querying real-time platform data.
- **Public Citizen Transparency Portal**: Open scheme outlays, village progress, and citizen grievance filing with auto-generated tracking codes (`GRV-2026-UP-xxxx`).
- **RBAC Governance Simulator**: 1-click role switcher to explore the portal as State Admin, District Officer, BDO, Field Inspector, Auditor, or Citizen.

---

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Vite
- **Styling**: Tailwind CSS v4, Plus Jakarta Sans, Noto Sans Devanagari
- **Data Visualization**: Recharts (Line, Grouped Bar, Horizontal Bar, Stacked Bar, Donut, Funnel)
- **Geographic Maps**: Leaflet, OpenStreetMap
- **Evidence Integrity**: Browser-native Web Crypto API (`crypto.subtle.digest`) for genuine SHA-256 hashing
- **Offline Storage**: IndexedDB & LocalStorage persistence with change queue & conflict resolution simulator
- **Icons**: Lucide React

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or 20+
- npm or yarn or bun

### Installation

```bash
# 1. Extract the zip file and navigate to the folder
cd gramsetu-techtrix26

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev
```

The app will be running at `http://localhost:3000`.

### Production Build

```bash
npm run build
npm run preview
```

---

## 📂 Project Structure

```
├── public/                 # Static assets and downloadable project zip
├── src/
│   ├── components/
│   │   ├── assistant/      # GramSetu Sahayak floating AI co-pilot
│   │   ├── common/         # Evidence inspection modal, StatCard, etc.
│   │   └── layout/         # AppShell, Topbar, Sidebar, Global Search
│   ├── context/            # Central reactive AppContext with state persistence
│   ├── data/               # Interconnected seed data (Districts, Schemes, Citizens)
│   ├── pages/              # 14 complete functional application modules
│   │   ├── OverviewDashboard.tsx
│   │   ├── SchemesProjects.tsx
│   │   ├── BeneficiaryVerification.tsx
│   │   ├── FieldInspections.tsx
│   │   ├── InstallmentApprovals.tsx
│   │   ├── RiskFraudDetection.tsx
│   │   ├── GeographicIntelligence.tsx
│   │   ├── OfflineWorkspace.tsx
│   │   ├── ReportsAnalytics.tsx
│   │   ├── AuditTrail.tsx
│   │   ├── PublicTransparencyPortal.tsx
│   │   ├── AIAssistantView.tsx
│   │   ├── UserRoleManagement.tsx
│   │   └── SettingsView.tsx
│   ├── services/           # Bilingual AI assistant service
│   ├── types/              # Comprehensive TypeScript interfaces
│   └── utils/              # SHA-256 WebCrypto utility & INR currency formatters
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## 🏆 TechTrix'26 PS-1 Demonstration Highlights for Judges

1. **Test Offline Sync**: Click the **Online/Offline** pill in the top navigation bar to simulate entering an area with zero rural internet connectivity. Fill out an inspection in the Field Inspections module, observe it queued in local IndexedDB, toggle online mode back on, and click **Push Sync to Central Server**.
2. **Inspect Evidence Cryptography**: Click on any photo proof or hash badge in the **Audit Trail** or **Beneficiary** modules to open the Digital Evidence Integrity Certificate with raw byte SHA-256 hash.
3. **Explore Explainable Risk Scoring**: Open **Risk & Fraud Detection** to inspect the duplicate image collision alert where two different applicants submitted the exact same construction photograph.
4. **Switch Roles**: Use the profile dropdown in the top right to switch between **Field Inspector**, **District Officer**, and **Public Citizen** to test permission boundaries.
5. **Ask GramSetu Sahayak**: Click the floating amber AI bubble at the bottom right and ask: *"मेरे ब्लॉक में कितने आवेदन लंबित हैं?"* or *"Show high-risk cases awaiting review."*
